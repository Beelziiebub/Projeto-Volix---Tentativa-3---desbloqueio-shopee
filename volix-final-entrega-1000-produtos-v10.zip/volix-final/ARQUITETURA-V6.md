# Volix V8 — Arquitetura

```text
Frontend
   |
   v
HTTP API / Cloud Run Service
   |
   v
Queue (local -> Pub/Sub em produção)
   |
   v
Collection Worker (local -> Cloud Run Job)
   |
   +--> Authorized Provider
   |
   +--> Public HTTP Collector (quando permitido)
   |       |
   |       +--> retry/backoff
   |       +--> anti-bot detection
   |       +--> circuit breaker/cooldown
   |
   +--> Fixture/Demo
   |
   v
Normalization
   |
   v
SQLite (local) / Cloud SQL (produção)
   |
   +--> Product
   +--> Price History
   +--> Collection Logs
```

## Princípios

- Provider separado da regra de negócio.
- Idempotência por URL/IDs do produto.
- Histórico de preços append-only.
- Falhas observáveis e diagnosticáveis.
- Retry com backoff, sem tentativa de contornar mecanismos de segurança.
- Fallback explicitamente identificado.
- Migração cloud preparada por interfaces e configuração.
