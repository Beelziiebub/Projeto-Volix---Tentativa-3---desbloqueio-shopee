# Estrutura do projeto Volix

## Execução

- `rodar` — atalho universal para Linux/macOS.
- `rodar-linux.sh` — atalho para Linux.
- `rodar-mac.sh` — atalho para macOS.
- `EXECUTAR-LINUX-MAC.sh` — atalho de compatibilidade.
- `EXECUTAR-WINDOWS.bat` — execução por duplo clique no Windows.
- `EXECUTAR-WINDOWS.ps1` — execução via PowerShell.
- `scripts/rodar-unix.sh` — fluxo central de execução Linux/macOS.
- `package.json` — comandos opcionais a partir da raiz (`npm test`, `npm start`, etc.).
- `.nvmrc` — versão principal recomendada do Node.js.

Todos os scripts fazem, na ordem: verificar Node 20+, instalar dependências, preparar seed, executar testes e iniciar o servidor. O servidor só é iniciado se as etapas anteriores terminarem com sucesso.

## Aplicação

- `frontend/index.html` — dashboard web responsivo.
- `backend/src/server.js` — API Express, fila, cache, scheduler e rotas.
- `backend/src/scraper.js` — coleta HTTP, detecção anti-bot e parser Shopee.
- `backend/src/repository.js` — persistência e consultas SQLite.
- `backend/src/db.js` — conexão e criação do schema.
- `backend/src/seed.js` — dados iniciais demonstrativos.
- `backend/tests/` — testes automatizados.
- `backend/data/volix.sqlite` — banco SQLite inicial.

## Documentação

- `README.md` — visão geral, instalação, API, limitações e checklist.
- `COMO-RODAR.md` — instruções de execução por sistema operacional.
- `DOCUMENTACAO_COMPLETA.md` — arquitetura, persistência, anti-bot, testes e decisões.
- `ESTRUTURA.md` — mapa dos arquivos e responsabilidades.
- `docker-compose.yml` — execução alternativa via Docker.

## Fluxo operacional

```text
URL/pesquisa
    ↓
API Express
    ↓
fila + cache
    ↓
scraper HTTP
    ↓
detecção anti-bot / retry / backoff
    ↓
parser
    ↓
repository
    ↓
SQLite
    ↓
dashboard + histórico + logs
```

## Comandos manuais

```bash
cd backend
npm install
npm run seed
npm test
npm start
```

## Comandos automáticos

Linux/macOS:

```bash
chmod +x rodar
./rodar
```

Windows: dê duplo clique em `EXECUTAR-WINDOWS.bat`.

Docker:

```bash
docker compose up
```
