@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ========================================
echo   VOLIX - Monitor de Precos Shopee
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 goto :node_error
where npm >nul 2>nul
if errorlevel 1 goto :npm_error

for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node"') do set NODE_MAJOR=%%v
if %NODE_MAJOR% LSS 20 goto :version_error

echo [1/5] Instalando dependencias do backend...
npm --prefix backend install
if errorlevel 1 goto :error

echo.
echo [2/5] Preparando banco SQLite...
npm --prefix backend run seed
if errorlevel 1 goto :error

echo.
echo [3/5] Executando testes...
npm --prefix backend test
if errorlevel 1 goto :error

echo.
echo [4/5] Verificando sintaxe JavaScript...
for %%F in (backend\src\*.js backend\tests\*.js) do node --check "%%F"
if errorlevel 1 goto :error

echo.
echo [5/5] Iniciando aplicacao...
echo Abra http://localhost:3000 no navegador.
echo Pressione Ctrl+C para encerrar.
echo.
npm --prefix backend start
exit /b %errorlevel%

:node_error
echo ERRO: Node.js nao foi encontrado. Instale Node.js 20 ou superior.
goto :fail
:npm_error
echo ERRO: npm nao foi encontrado.
goto :fail
:version_error
echo ERRO: este projeto requer Node.js 20 ou superior.
node --version
goto :fail
:error
echo.
echo ERRO: uma das etapas falhou.
:fail
pause
exit /b 1
