#!/usr/bin/env bash
# Volix — fluxo completo para Linux e macOS.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"

fail() {
  echo
  echo "[ERRO] $1" >&2
  exit 1
}

command -v node >/dev/null 2>&1 || fail "Node.js não foi encontrado. Instale Node.js 20 ou superior."
command -v npm >/dev/null 2>&1 || fail "npm não foi encontrado. Instale Node.js 20 ou superior."

NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
(( NODE_MAJOR >= 20 )) || fail "Node.js 20+ é obrigatório. Versão encontrada: $(node --version)"

cd "$ROOT_DIR"

cat <<'BANNER'
========================================
  VOLIX — Monitor de preços Shopee
========================================
BANNER
printf 'Node: %s\nnpm:  %s\n\n' "$(node --version)" "$(npm --version)"

echo "[1/5] Instalando dependências do backend..."
npm --prefix backend install

echo
echo "[2/5] Preparando banco SQLite..."
npm --prefix backend run seed

echo
echo "[3/5] Executando testes..."
npm --prefix backend test

echo
echo "[4/5] Verificando sintaxe dos arquivos JavaScript..."
for file in backend/src/*.js backend/tests/*.js; do
  node --check "$file"
done

echo
echo "[5/5] Iniciando aplicação..."
echo "Dashboard: http://localhost:3000"
echo "Health:    http://localhost:3000/api/health"
echo "Pressione Ctrl+C para encerrar."
echo
npm --prefix backend start
