# Como rodar o projeto Volix

O projeto já contém os scripts de execução dentro da própria pasta. Não é necessário criar comandos adicionais.

## Requisitos

- Node.js 20 ou superior
- npm (instalado junto com Node.js)
- Navegador moderno

## Windows — duplo clique

1. Extraia o ZIP.
2. Abra a pasta `volix-final`.
3. Dê duplo clique em `EXECUTAR-WINDOWS.bat`.
4. O script verifica Node.js, instala dependências, prepara o SQLite, executa os testes e inicia o servidor.
5. Abra `http://localhost:3000`.

Alternativa PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\EXECUTAR-WINDOWS.ps1
```

## Linux — um comando

Na pasta `volix-final`:

```bash
chmod +x rodar-linux.sh
./rodar-linux.sh
```

## macOS — um comando

Na pasta `volix-final`:

```bash
chmod +x rodar-mac.sh
./rodar-mac.sh
```

## Linux/macOS — atalho universal

```bash
chmod +x rodar
./rodar
```

O arquivo `rodar` chama `scripts/rodar-unix.sh`, que centraliza o fluxo para evitar duplicação.

## O que o script faz automaticamente

```text
1. Verifica Node.js 20+
2. Verifica npm
3. Entra no projeto
4. Instala dependências do backend
5. Prepara o SQLite
6. Executa os testes
7. Verifica a sintaxe JavaScript
8. Inicia o servidor
```

Se qualquer etapa falhar, a execução é interrompida e o servidor não é iniciado.

## Execução manual

Caso queira executar etapa por etapa:

```bash
cd backend
npm install
npm run seed
npm test
npm start
```

## Docker

Na raiz do projeto:

```bash
docker compose up
```

## Endereços

- Dashboard: `http://localhost:3000`
- Health check: `http://localhost:3000/api/health`

## Banco

O banco SQLite fica em `backend/data/volix.sqlite`.

## Estrutura

Consulte `ESTRUTURA.md` para o mapa completo da pasta e responsabilidades de cada arquivo.


### Catálogo de demonstração
O seed recria exatamente 1000 produtos locais e funcionais para a apresentação, sem depender da coleta pública da Shopee.
