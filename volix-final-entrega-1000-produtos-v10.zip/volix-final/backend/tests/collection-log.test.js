import test from 'node:test';
import assert from 'node:assert/strict';
import db from '../src/db.js';
import { addCollectionLog, getStats, listCollectionLogs } from '../src/repository.js';

test('logs e métricas de coleta são persistidos', () => {
  const before = listCollectionLogs(500).length;
  addCollectionLog({status:'success',message:'Teste automatizado',duration_ms:12});
  const logs = listCollectionLogs(500);
  assert.equal(logs.length, before + 1);
  assert.equal(logs[0].status, 'success');
  assert.equal(logs[0].message, 'Teste automatizado');
  assert.ok(getStats().successful_24h >= 1);
  db.prepare("DELETE FROM collection_log WHERE message='Teste automatizado'").run();
});
