const publicBlockedUntil = new Map();
const publicBlockReason = new Map();

const num = (v, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

export function providerMode() {
  return String(process.env.SHOPEE_PROVIDER_MODE || 'fixture').trim().toLowerCase();
}

export function publicCooldownMs() {
  return Math.max(0, num(process.env.PUBLIC_COLLECTION_COOLDOWN_MS, 15 * 60 * 1000));
}

export function publicCollectionAvailable(host = 'shopee.com.br') {
  const until = publicBlockedUntil.get(host) || 0;
  return Date.now() >= until;
}

export function markPublicBlocked(host = 'shopee.com.br', reason = 'ANTI_BOT_CHALLENGE', retryAfterMs = publicCooldownMs()) {
  const until = Date.now() + Math.max(publicCooldownMs(), retryAfterMs || 0);
  publicBlockedUntil.set(host, until);
  publicBlockReason.set(host, reason);
  return until;
}

export function clearPublicBlock(host = 'shopee.com.br') {
  publicBlockedUntil.delete(host);
  publicBlockReason.delete(host);
}

export function publicProviderStatus(host = 'shopee.com.br') {
  const until = publicBlockedUntil.get(host) || 0;
  return {
    available: Date.now() >= until,
    blocked_until: until ? new Date(until).toISOString() : null,
    reason: publicBlockReason.get(host) || null
  };
}

export function providerStatus({ authorized = false, host = 'shopee.com.br' } = {}) {
  return {
    mode: providerMode(),
    authorized_configured: Boolean(authorized),
    public_http: publicProviderStatus(host),
    fixture_fallback: String(process.env.FIXTURE_FALLBACK || 'true').toLowerCase() !== 'false'
  };
}
