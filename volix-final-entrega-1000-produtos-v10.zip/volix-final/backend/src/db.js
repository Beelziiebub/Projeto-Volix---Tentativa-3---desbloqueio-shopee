import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(__dirname, '../data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'volix.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS product (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 shopee_item_id TEXT UNIQUE,
 shopee_shop_id TEXT,
 name TEXT NOT NULL,
 description TEXT,
 url TEXT NOT NULL UNIQUE,
 brand TEXT,
 seller TEXT,
 rating REAL,
 rating_count INTEGER,
 sold_count INTEGER,
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS product_attribute (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
 key TEXT NOT NULL,
 value TEXT,
 UNIQUE(product_id,key)
);
CREATE TABLE IF NOT EXISTS price_history (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
 price_pix REAL,
 price_card REAL,
 currency TEXT NOT NULL DEFAULT 'BRL',
 collected_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CHECK(price_pix IS NOT NULL OR price_card IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS product_image (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
 url TEXT NOT NULL,
 position INTEGER NOT NULL DEFAULT 0,
 UNIQUE(product_id,url)
);
CREATE TABLE IF NOT EXISTS product_variant (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
 sku TEXT,
 name TEXT,
 price_pix REAL,
 price_card REAL,
 UNIQUE(product_id,sku,name)
);
CREATE INDEX IF NOT EXISTS idx_price_product_date ON price_history(product_id,collected_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS idx_attr_product ON product_attribute(product_id);
CREATE TABLE IF NOT EXISTS collection_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER REFERENCES product(id) ON DELETE SET NULL,
 status TEXT NOT NULL CHECK(status IN ('success','blocked','error')),
 message TEXT NOT NULL,
 duration_ms INTEGER,
 collected_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_collection_log_date ON collection_log(collected_at DESC,id DESC);
`);

// Migração leve para versões anteriores do projeto.
const productColumns = db.prepare('PRAGMA table_info(product)').all().map(x=>x.name);
if (!productColumns.includes('data_source')) db.exec("ALTER TABLE product ADD COLUMN data_source TEXT NOT NULL DEFAULT 'unknown'");

export default db;
