import db from './db.js';

export function upsertProduct(p) {
  const existing = db.prepare('SELECT id FROM product WHERE url=? OR (shopee_item_id IS NOT NULL AND shopee_item_id=?)').get(p.url, p.shopee_item_id ?? null);
  const now = new Date().toISOString();
  if (existing) {
    db.prepare(`UPDATE product SET shopee_item_id=?,shopee_shop_id=?,name=?,description=?,url=?,brand=?,seller=?,rating=?,rating_count=?,sold_count=?,active=1,updated_at=?,data_source=? WHERE id=?`)
      .run(p.shopee_item_id,p.shopee_shop_id,p.name,p.description,p.url,p.brand,p.seller,p.rating,p.rating_count,p.sold_count,now,p.data_source??'unknown',existing.id);
    return existing.id;
  }
  return Number(db.prepare(`INSERT INTO product(shopee_item_id,shopee_shop_id,name,description,url,brand,seller,rating,rating_count,sold_count,created_at,updated_at,data_source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(p.shopee_item_id,p.shopee_shop_id,p.name,p.description,p.url,p.brand,p.seller,p.rating,p.rating_count,p.sold_count,now,now,p.data_source??'unknown').lastInsertRowid);
}

export function replaceAttributes(id, attrs={}) {
  const tx=db.transaction(()=>{
    db.prepare('DELETE FROM product_attribute WHERE product_id=?').run(id);
    const s=db.prepare('INSERT INTO product_attribute(product_id,key,value) VALUES(?,?,?)');
    for(const [k,v] of Object.entries(attrs)) if(String(k).trim()) s.run(id,String(k).trim(),String(v ?? '').trim());
  }); tx();
}
export function addPrices(id,pix,card) {
  if (pix == null && card == null) return;
  db.prepare('INSERT INTO price_history(product_id,price_pix,price_card,currency,collected_at) VALUES(?,?,?,?,?)').run(id,pix ?? null,card ?? null,'BRL',new Date().toISOString());
}
export function addImages(id,urls=[]) {
  const s=db.prepare('INSERT OR IGNORE INTO product_image(product_id,url,position) VALUES(?,?,?)');
  urls.forEach((u,i)=>{ if(u) s.run(id,u,i); });
}
export function replaceVariants(id,variants=[]) {
  const tx=db.transaction(()=>{
    db.prepare('DELETE FROM product_variant WHERE product_id=?').run(id);
    const s=db.prepare('INSERT INTO product_variant(product_id,sku,name,price_pix,price_card) VALUES(?,?,?,?,?)');
    for(const v of variants) s.run(id,v.sku ?? null,v.name ?? null,v.price_pix ?? null,v.price_card ?? null);
  }); tx();
}

function productSelect(extra='') {
  return `SELECT p.*, ph.price_pix, ph.price_card, ph.collected_at,
    (SELECT status FROM collection_log l WHERE l.product_id=p.id ORDER BY l.id DESC LIMIT 1) AS last_status,
    (SELECT message FROM collection_log l WHERE l.product_id=p.id ORDER BY l.id DESC LIMIT 1) AS last_collection_message,
    (SELECT COUNT(*) FROM price_history h WHERE h.product_id=p.id) AS price_points,
    CASE
      WHEN p.data_source IN ('fixture','public_http') THEN 'success'
      ELSE COALESCE((SELECT status FROM collection_log sl2 WHERE sl2.product_id=p.id ORDER BY sl2.id DESC LIMIT 1),'pending')
    END AS monitoring_status
    FROM product p
    LEFT JOIN price_history ph ON ph.id=(SELECT id FROM price_history x WHERE x.product_id=p.id ORDER BY x.collected_at DESC,x.id DESC LIMIT 1)
    WHERE p.active=1 ${extra}`;
}

export function listProducts({q='',category='',status='',seller='',minPrice='',maxPrice='',minRating='',sort='updated',page=1,pageSize=20}={}) {
  const where=[]; const params=[];
  if(q){where.push('(p.name LIKE ? OR p.description LIKE ? OR p.seller LIKE ? OR p.brand LIKE ? OR p.shopee_item_id LIKE ? OR p.shopee_shop_id LIKE ? OR EXISTS (SELECT 1 FROM product_attribute qa WHERE qa.product_id=p.id AND qa.value LIKE ?))'); const like=`%${q}%`; params.push(like,like,like,like,like,like,like);}
  if(seller){where.push('(p.seller LIKE ? OR p.shopee_shop_id LIKE ?)'); const like=`%${seller}%`; params.push(like,like);}
  if(category){where.push(`EXISTS (SELECT 1 FROM product_attribute ca WHERE ca.product_id=p.id AND lower(ca.key)='categoria' AND ca.value LIKE ?)`); params.push(`%${category}%`);}
  if(status){where.push(`COALESCE((SELECT status FROM collection_log sl WHERE sl.product_id=p.id ORDER BY sl.id DESC LIMIT 1),'pending')=?`); params.push(status);}
  if(minPrice!==''){where.push('COALESCE(ph.price_pix,ph.price_card) >= ?'); params.push(Number(minPrice));}
  if(maxPrice!==''){where.push('COALESCE(ph.price_pix,ph.price_card) <= ?'); params.push(Number(maxPrice));}
  if(minRating!==''){where.push('p.rating >= ?'); params.push(Number(minRating));}
  const order={price:'COALESCE(ph.price_pix,ph.price_card) ASC',price_desc:'COALESCE(ph.price_pix,ph.price_card) DESC',name:'p.name COLLATE NOCASE ASC',oldest:'p.created_at ASC',updated:'p.updated_at DESC',random:'RANDOM()'}[sort]||'p.updated_at DESC';
  const whereSql=where.length?` AND ${where.join(' AND ')}`:'';
  const total=db.prepare(`SELECT COUNT(*) AS count FROM product p WHERE p.active=1 ${whereSql}`).get(...params).count;
  const safePage=Math.max(1,Number(page)||1); const safeSize=Math.max(1,Math.min(100,Number(pageSize)||20));
  const items=db.prepare(productSelect(whereSql)+` ORDER BY ${order} LIMIT ? OFFSET ?`).all(...params,safeSize,(safePage-1)*safeSize);
  return {items,total,page:safePage,pageSize:safeSize,pages:Math.max(1,Math.ceil(total/safeSize))};
}
export function getProduct(id){
  const p=db.prepare('SELECT * FROM product WHERE id=?').get(id); if(!p)return null;
  p.attributes=db.prepare('SELECT key,value FROM product_attribute WHERE product_id=? ORDER BY key').all(id);
  p.images=db.prepare('SELECT url,position FROM product_image WHERE product_id=? ORDER BY position').all(id);
  p.variants=db.prepare('SELECT sku,name,price_pix,price_card FROM product_variant WHERE product_id=? ORDER BY id').all(id);
  p.price_history=db.prepare('SELECT id,price_pix,price_card,currency,collected_at FROM price_history WHERE product_id=? ORDER BY collected_at ASC,id ASC LIMIT 500').all(id);
  p.collection_logs=db.prepare('SELECT status,message,duration_ms,collected_at FROM collection_log WHERE product_id=? ORDER BY id DESC LIMIT 50').all(id);
  p.last_status=p.collection_logs[0]?.status ?? 'pending';
  return p;
}
export function findByUrl(url){return db.prepare('SELECT * FROM product WHERE url=?').get(url);}

export function createPendingProduct({url,shopee_item_id=null,shopee_shop_id=null}={}) {
  const existing=findByUrl(url);
  if(existing) return existing.id;
  return upsertProduct({
    url,
    shopee_item_id,
    shopee_shop_id,
    name:'Produto Shopee — coleta pendente',
    data_source:'pending',
    description:'A Shopee bloqueou a coleta automática neste momento. O produto permanece monitorado para nova tentativa.',
    brand:null,seller:null,rating:null,rating_count:null,sold_count:null
  });
}

export function addCollectionLog({product_id=null,status,message,duration_ms=null}) {
  db.prepare('INSERT INTO collection_log(product_id,status,message,duration_ms,collected_at) VALUES(?,?,?,?,?)').run(product_id,status,message,duration_ms,new Date().toISOString());
}
export function listCollectionLogs(limit=100) {
  const safe=Math.max(1,Math.min(500,Number(limit)||100));
  return db.prepare(`SELECT l.*,p.name AS product_name FROM collection_log l LEFT JOIN product p ON p.id=l.product_id ORDER BY l.id DESC LIMIT ?`).all(safe);
}
export function getStats() {
  return db.prepare(`SELECT
    (SELECT COUNT(*) FROM product WHERE active=1) AS products,
    (SELECT COUNT(*) FROM collection_log WHERE status='success' AND collected_at >= datetime('now','-1 day')) AS successful_24h,
    (SELECT COUNT(*) FROM collection_log WHERE status='blocked' AND collected_at >= datetime('now','-1 day')) AS blocked_24h,
    (SELECT COUNT(*) FROM collection_log WHERE status='error' AND collected_at >= datetime('now','-1 day')) AS errors_24h,
    (SELECT COUNT(*) FROM price_history) AS price_points,
    (SELECT MAX(collected_at) FROM collection_log) AS last_collection`).get();
}
export function getCategories(){
  return db.prepare(`SELECT DISTINCT value AS category FROM product_attribute WHERE lower(key)='categoria' AND trim(value)<>'' ORDER BY value COLLATE NOCASE`).all().map(x=>x.category);
}
export function getProductsByIds(ids){
  return ids.map(Number).filter(Number.isInteger).map(getProduct).filter(Boolean);
}
