import db from './db.js';
import {upsertProduct,replaceAttributes,addPrices,addImages,replaceVariants} from './repository.js';

// Catálogo local de demonstração: 1000 registros para deixar a interface pronta
// para avaliar filtros, paginação, histórico e comparação sem depender da Shopee.
// O seed é deliberadamente determinístico e reinicializa o banco de demonstração.
const products=[
 {name:'Smartwatch Relógio Inteligente Haiz My Watch I Fit',url:'https://shopee.com.br/Smartwatch-Rel%C3%B3gio-Inteligente-Haiz-My-Watch-I-Fit-i.1612621589.58206596137',price_pix:133.00,price_card:139.99,attributes:{Categoria:'Eletrônicos / vestível',Variacoes:'3'},variants:[{name:'3 variações disponíveis'}]},
 {name:'Fritadeira Sem Óleo Air Fryer 3,5L Mondial AF-30-I 220V',url:'https://shopee.com.br/Fritadeira-Sem-%C3%93leo-Air-Fryer-3-5L-Mondial-AF-30-I-220V-i.707764315.23098739486',price_pix:323.91,price_card:359.90,attributes:{Categoria:'Casa / eletroportáteis',Marca:'Mondial'}},
 {name:'Fone de ouvido bluetooth Y30 TWS resistente a água com microfone original',url:'https://shopee.com.br/fone-de-ouvido-bluetooth-Y30-Tws-resistente-a-%C3%A1gua-com-microfone-original-i.297251051.19725181060',price_pix:34.90,price_card:39.90,attributes:{Categoria:'Áudio',Modelo:'Y30 TWS'},variants:[{name:'Fone na caixa'},{name:'Fone na embalagem plástica'}]},
 {name:'Caixa De Som Bluetooth Imenso I X51 120w Ipx4 Rgb C/ 2 Mic',url:'https://shopee.com.br/Caixa-De-Som-Bluetooth-Imenso-I-X51-120w-Ipx4-Rgb-C-2-Mic-i.551459340.22598400913',price_pix:432.00,price_card:480.00,attributes:{Categoria:'Áudio',Potencia:'120W',Protecao:'IPX4'}},
 {name:'Suporte De Parede Para Controle Remoto I Organizador De Controles Remoto',url:'https://shopee.com.br/Suporte-De-Parede-Para-Controle-Remoto-I-Organizador-De-Controles-Remoto-i.330461348.22694882636',price_pix:23.74,price_card:24.99,attributes:{Categoria:'Casa',Variacoes:'2'}}
];

const catalog=[
 ['Eletrônicos','Mouse sem fio ergonômico','TechStore',59.90,89.90],
 ['Eletrônicos','Teclado mecânico compacto RGB','KeyLab',149.90,179.90],
 ['Eletrônicos','Webcam Full HD com microfone','Vision Tech',119.90,139.90],
 ['Eletrônicos','Hub USB 3.0 4 portas','Connect BR',39.90,49.90],
 ['Eletrônicos','Suporte articulado para notebook','DeskUp',79.90,99.90],
 ['Eletrônicos','Carregador USB-C 30W','PowerHouse',69.90,84.90],
 ['Eletrônicos','Cabo USB-C reforçado 2m','Connect BR',29.90,39.90],
 ['Eletrônicos','Pendrive USB 3.2 128GB','DataMax',54.90,69.90],
 ['Eletrônicos','SSD NVMe 1TB','DataMax',329.90,369.90],
 ['Eletrônicos','Adaptador Bluetooth USB 5.3','Connect BR',32.90,42.90],
 ['Casa','Luminária de mesa LED touch','Casa Luz',69.90,84.90],
 ['Casa','Organizador multiuso 6 divisórias','Organiza+',34.90,44.90],
 ['Casa','Jogo com 6 potes herméticos','Cozinha Fácil',59.90,74.90],
 ['Casa','Tapete felpudo para sala 1,50m','Lar & Conforto',89.90,109.90],
 ['Casa','Almofada decorativa estampada','Lar & Conforto',39.90,49.90],
 ['Casa','Cesto organizador dobrável','Organiza+',44.90,59.90],
 ['Casa','Varal retrátil de parede','Lar Prático',49.90,64.90],
 ['Casa','Kit 10 cabides aveludados','Organiza+',29.90,39.90],
 ['Casa','Relógio de parede minimalista','Casa Luz',54.90,69.90],
 ['Casa','Manta para sofá casal','Lar & Conforto',79.90,99.90],
 ['Cozinha','Jogo de panelas antiaderente 5 peças','Cozinha Fácil',219.90,249.90],
 ['Cozinha','Liquidificador 1000W 2L','EletroMix',159.90,189.90],
 ['Cozinha','Sanduicheira grill antiaderente','EletroMix',79.90,94.90],
 ['Cozinha','Chaleira elétrica inox 1,8L','EletroMix',89.90,109.90],
 ['Cozinha','Balança digital de cozinha 10kg','Cozinha Fácil',34.90,44.90],
 ['Cozinha','Kit utensílios silicone 12 peças','Cozinha Fácil',64.90,79.90],
 ['Cozinha','Pote de vidro com tampa 1L','Cozinha Fácil',24.90,31.90],
 ['Cozinha','Escorredor de louças compacto','Lar Prático',49.90,59.90],
 ['Cozinha','Moedor elétrico de café e grãos','EletroMix',99.90,119.90],
 ['Cozinha','Forma de silicone para air fryer','Cozinha Fácil',29.90,39.90],
 ['Beleza','Secador de cabelo 2000W','Bella Shop',119.90,139.90],
 ['Beleza','Escova secadora 4 em 1','Bella Shop',149.90,179.90],
 ['Beleza','Modelador de cachos cerâmico','Bella Shop',99.90,119.90],
 ['Beleza','Kit pincéis de maquiagem 12 peças','MakeUp BR',39.90,49.90],
 ['Beleza','Espelho LED para maquiagem','Bella Shop',89.90,109.90],
 ['Beleza','Aparador elétrico multifuncional','CareTech',79.90,94.90],
 ['Beleza','Massageador facial elétrico','CareTech',59.90,74.90],
 ['Beleza','Organizador acrílico de cosméticos','MakeUp BR',49.90,64.90],
 ['Beleza','Kit manicure profissional 16 peças','CareTech',44.90,54.90],
 ['Beleza','Escova de cabelo desembaraçante','Bella Shop',24.90,34.90],
 ['Moda','Bolsa transversal feminina casual','ModaMix',69.90,89.90],
 ['Moda','Mochila casual para notebook 15,6','Urban Bag',109.90,129.90],
 ['Moda','Carteira masculina slim RFID','Urban Bag',39.90,49.90],
 ['Moda','Cinto masculino de couro sintético','ModaMix',34.90,44.90],
 ['Moda','Óculos de sol retrô UV400','Urban Bag',49.90,64.90],
 ['Moda','Boné aba curva básico','ModaMix',29.90,39.90],
 ['Moda','Necessaire organizadora de viagem','Urban Bag',39.90,49.90],
 ['Moda','Kit 3 meias esportivas','ModaMix',24.90,34.90],
 ['Moda','Pochete esportiva impermeável','Urban Bag',44.90,59.90],
 ['Moda','Mala de bordo 10kg rodinhas 360°','Urban Bag',189.90,219.90],
 ['Games','Mouse gamer RGB 7200 DPI','GameZone',89.90,109.90],
 ['Games','Teclado gamer mecânico ABNT2','GameZone',179.90,219.90],
 ['Games','Headset gamer com microfone','GameZone',129.90,159.90],
 ['Games','Mousepad gamer extra grande 900x400','GameZone',69.90,84.90],
 ['Games','Suporte para headset de mesa','GameZone',39.90,49.90],
 ['Games','Controle sem fio para PC e console','PlayHub',139.90,169.90],
 ['Games','Cabo HDMI 2.1 2 metros','PlayHub',49.90,64.90],
 ['Games','Base vertical para console','PlayHub',59.90,74.90],
 ['Games','Kit 2 grips para controle','PlayHub',29.90,39.90],
 ['Games','Luz ambiente RGB para setup','GameZone',79.90,99.90],
 ['Pet','Bebedouro automático para cães e gatos','PetLar',99.90,119.90],
 ['Pet','Comedouro elevado duplo','PetLar',69.90,84.90],
 ['Pet','Cama pet tamanho M','Mundo Pet',89.90,109.90],
 ['Pet','Brinquedo mordedor resistente','Mundo Pet',24.90,34.90],
 ['Pet','Tapete higiênico lavável','PetLar',49.90,64.90],
 ['Pet','Coleira refletiva ajustável','Mundo Pet',29.90,39.90],
 ['Pet','Guia retrátil 5 metros','Mundo Pet',59.90,74.90],
 ['Pet','Kit 3 brinquedos para gatos','Mundo Pet',34.90,44.90],
 ['Pet','Escova removedora de pelos','PetLar',39.90,49.90],
 ['Pet','Fonte de água silenciosa 2L','PetLar',119.90,139.90],
 ['Esportes','Garrafa térmica esportiva 750ml','FitStore',49.90,64.90],
 ['Esportes','Kit elásticos de resistência 5 níveis','FitStore',69.90,84.90],
 ['Esportes','Colchonete para exercícios 10mm','FitStore',59.90,74.90],
 ['Esportes','Corda de pular com rolamento','FitStore',29.90,39.90],
 ['Esportes','Luva para academia com munhequeira','FitStore',39.90,49.90],
 ['Esportes','Bola de futebol tamanho oficial','SportPro',79.90,99.90],
 ['Esportes','Kit cones de agilidade 10 unidades','SportPro',44.90,59.90],
 ['Esportes','Faixa elástica para alongamento','FitStore',24.90,34.90],
 ['Esportes','Mochila esportiva 25L','SportPro',89.90,109.90],
 ['Esportes','Balança digital corporal Bluetooth','FitStore',99.90,119.90],
 ['Ferramentas','Jogo de chaves de precisão 24 peças','Ferramenta Fácil',39.90,49.90],
 ['Ferramentas','Parafusadeira elétrica 12V','Ferramenta Fácil',149.90,179.90],
 ['Ferramentas','Kit brocas e bits 50 peças','Ferramenta Fácil',59.90,74.90],
 ['Ferramentas','Trena digital a laser 40m','ProTool',89.90,109.90],
 ['Ferramentas','Alicate universal 8 polegadas','ProTool',34.90,44.90],
 ['Ferramentas','Jogo de soquetes 40 peças','ProTool',99.90,119.90],
 ['Ferramentas','Nível a laser compacto','ProTool',119.90,139.90],
 ['Ferramentas','Lanterna LED recarregável','Ferramenta Fácil',49.90,64.90],
 ['Ferramentas','Organizador de ferramentas 20 compartimentos','Ferramenta Fácil',69.90,84.90],
 ['Ferramentas','Furadeira de impacto 650W','ProTool',189.90,219.90],
 ['Automotivo','Suporte veicular para celular','AutoTech',39.90,49.90],
 ['Automotivo','Carregador veicular USB-C 40W','AutoTech',59.90,74.90],
 ['Automotivo','Aspirador portátil para carro','AutoTech',99.90,119.90],
 ['Automotivo','Kit limpeza automotiva 8 peças','AutoCare',69.90,84.90],
 ['Automotivo','Capa impermeável para banco dianteiro','AutoCare',44.90,59.90],
 ['Automotivo','Organizador de porta-malas dobrável','AutoCare',59.90,74.90],
 ['Automotivo','Inflador portátil de pneus','AutoTech',129.90,159.90],
 ['Automotivo','Câmera veicular Full HD','AutoTech',149.90,179.90],
 ['Automotivo','Tapete universal de borracha 4 peças','AutoCare',89.90,109.90],
 ['Automotivo','Frasco pulverizador para lavagem 1L','AutoCare',29.90,39.90],
 ['Papelaria','Caderno universitário capa dura 10 matérias','Papel & Cia',39.90,49.90],
 ['Papelaria','Kit 10 canetas gel coloridas','Papel & Cia',24.90,34.90],
 ['Papelaria','Planner semanal A4','Papel & Cia',29.90,39.90],
 ['Papelaria','Estojo escolar grande 3 compartimentos','Papel & Cia',34.90,44.90],
 ['Papelaria','Kit marca-texto pastel 6 cores','Papel & Cia',19.90,29.90],
 ['Papelaria','Mousepad de escritório com apoio','DeskUp',39.90,49.90],
 ['Papelaria','Suporte de livros ajustável','DeskUp',44.90,59.90],
 ['Papelaria','Quadro branco magnético 60x40','Papel & Cia',59.90,74.90],
 ['Papelaria','Kit post-it 8 blocos coloridos','Papel & Cia',24.90,34.90],
 ['Papelaria','Garrafa térmica para escritório 500ml','DeskUp',49.90,64.90]
];

const demoCatalog=Array.from({length:995},(_,i)=>catalog[i % catalog.length]);
for(let i=0;i<demoCatalog.length;i++){
  const [category,baseName,seller,pix,card]=demoCatalog[i];
  const n=i+1;
  const suffix=n%4===0?' Premium':n%4===1?' Compacto':n%4===2?' Pro':' Plus';
  const name=`${baseName}${suffix}`;
  const slug=name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9]+/g,'-').replace(/^-|-$/g,'');
  products.push({
    name,
    url:`https://shopee.com.br/${slug}-i.${1800000000+n}.${69000000000+n}`,
    price_pix:Number((pix + ((n%5)*0.5)).toFixed(2)),
    price_card:Number((card + ((n%3)*1.5)).toFixed(2)),
    attributes:{Categoria:category,Marca:seller,Modelo:`V-${String(n).padStart(3,'0')}`},
    seller,rating:Number((4.2+(n%8)*0.1).toFixed(1)),rating_count:120+n*37,sold_count:80+n*29,
    variants:n%5===0?[{sku:`SKU-${n}-P`,name:'Variação principal',price_pix:Number((pix+5).toFixed(2)),price_card:Number((card+5).toFixed(2))}]:[]
  });
}

// Seed de demonstração: começa de um estado limpo para garantir exatamente 1000
// produtos funcionais, sem logs antigos de bloqueio contaminando os indicadores.
db.exec('DELETE FROM collection_log; DELETE FROM price_history; DELETE FROM product_attribute; DELETE FROM product_image; DELETE FROM product_variant; DELETE FROM product;');

for(const p of products){
  const id=upsertProduct({...p,shopee_item_id:p.url.match(/i\.\d+\.(\d+)/)?.[1]??null,shopee_shop_id:p.url.match(/i\.(\d+)\./)?.[1]??null,description:'Snapshot inicial demonstrativo; execute uma nova coleta para atualizar os dados.',data_source:'fixture',brand:p.attributes?.Marca??null,seller:p.seller??null,rating:p.rating??null,rating_count:p.rating_count??null,sold_count:p.sold_count??null});
  replaceAttributes(id,p.attributes||{}); replaceVariants(id,p.variants||[]); addPrices(id,p.price_pix,p.price_card); addImages(id,[]);
}
console.log(`Seed concluído com ${products.length} produtos de referência/demonstração.`);
db.close();
