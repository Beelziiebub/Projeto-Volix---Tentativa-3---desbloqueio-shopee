import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cron from 'node-cron';
import './db.js';
import db from './db.js';
import { upsertProduct, createPendingProduct, replaceAttributes, addPrices, addImages, replaceVariants, listProducts, getProduct, addCollectionLog, listCollectionLogs, getStats, getCategories, getProductsByIds } from './repository.js';
import { scrapeShopee, searchShopee } from './scraper.js';
import { fixtureForUrl, fixtureToProduct, listFixtures } from './fixtures.js';
import { authorizedProviderConfigured, collectFromAuthorizedProvider } from './providers.js';
import { providerMode, publicCollectionAvailable, markPublicBlocked, clearPublicBlock, providerStatus } from './provider-manager.js';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use((req,res,next)=>{
  // Permite abrir o frontend localmente em file:// durante desenvolvimento.
  // Em produção, sirva o frontend pelo próprio Express para manter same-origin.
  const origin=req.headers.origin;
  if(origin && (origin==='null' || /^https?:\/\/localhost(?::\d+)?$/i.test(origin))){
    res.setHeader('Access-Control-Allow-Origin',origin);
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Headers','Content-Type');
    res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  }
  if(req.method==='OPTIONS')return res.sendStatus(204);
  next();
});
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.resolve(__dirname,'../../frontend')));
const isShopeeUrl=v=>/^https?:\/\/(?:www\.)?shopee\.com\.br\/.+?-i\.\d+\.\d+(?:[/?#].*)?$/i.test(String(v||''));
const validId=v=>Number.isInteger(Number(v))&&Number(v)>0;

const queue=[]; let running=false;
const cache=new Map(); const CACHE_TTL=Number(process.env.SCRAPE_CACHE_TTL_MS||60000);
const FIXTURE_FALLBACK=String(process.env.FIXTURE_FALLBACK||'true').toLowerCase()!=='false';
const lastDiagnostics=new Map();
function getFixture(url){
  const fixture=fixtureForUrl(String(url||'').trim());
  return fixture;
}
function enqueue(task){ return new Promise((resolve,reject)=>{queue.push({task,resolve,reject});processQueue();}); }
async function processQueue(){ if(running)return; running=true; while(queue.length){const item=queue.shift();try{item.resolve(await item.task());}catch(e){item.reject(e);}} running=false; }

app.get('/api/health',(_,res)=>{try{db.prepare('SELECT 1 AS ok').get();res.json({ok:true,database:'connected',queue:queue.length,running,authorized_provider:authorizedProviderConfigured(),providers:providerStatus({authorized:authorizedProviderConfigured()}),time:new Date().toISOString(),uptime:Math.round(process.uptime())});}catch(e){res.status(503).json({ok:false,database:'error',detail:e.message});}});
app.get('/api/stats',(_,res)=>res.json({...getStats(),queue_size:queue.length,queue_running:running,providers:providerStatus({authorized:authorizedProviderConfigured()})}));
app.get('/api/providers',(req,res)=>res.json(providerStatus({authorized:authorizedProviderConfigured()})));
app.post('/api/providers/public/reset',(req,res)=>{clearPublicBlock();res.json({ok:true,providers:providerStatus({authorized:authorizedProviderConfigured()})});});
app.get('/api/logs',(req,res)=>res.json(listCollectionLogs(req.query.limit)));
app.get('/api/diagnostics',(req,res)=>res.json([...lastDiagnostics.values()].slice(-50).reverse()));
app.get('/api/diagnostics/fixture',(req,res)=>{const url=String(req.query.url||'').trim();const f=getFixture(url);res.json({enabled:FIXTURE_FALLBACK,matched:Boolean(f),url,fixture:f?{name:f.name,price_pix:f.price_pix,price_card:f.price_card}:null});});
app.get('/api/fixtures',(req,res)=>res.json({enabled:FIXTURE_FALLBACK,items:listFixtures().map(x=>({name:x.name,url:x.url,price_pix:x.price_pix,price_card:x.price_card}))}));
app.get('/api/categories',(_,res)=>res.json(getCategories()));
app.get('/api/products',(req,res)=>res.json(listProducts({q:String(req.query.q||'').trim(),category:String(req.query.category||'').trim(),status:String(req.query.status||'').trim(),seller:String(req.query.seller||'').trim(),minPrice:String(req.query.minPrice||'').trim(),maxPrice:String(req.query.maxPrice||'').trim(),minRating:String(req.query.minRating||'').trim(),sort:String(req.query.sort||'updated'),page:req.query.page,pageSize:req.query.pageSize})));
app.get('/api/products/:id',(req,res)=>{if(!validId(req.params.id))return res.status(400).json({error:'ID inválido'});const p=getProduct(Number(req.params.id));if(!p)return res.status(404).json({error:'Produto não encontrado'});res.json(p);});
app.get('/api/compare',(req,res)=>{const ids=String(req.query.ids||'').split(',').map(Number).filter(Number.isInteger).slice(0,5);if(ids.length<2)return res.status(400).json({error:'Informe pelo menos 2 IDs em ids=1,2'});res.json(getProductsByIds(ids));});
app.get('/api/export.csv',(req,res)=>{const result=listProducts({q:String(req.query.q||''),category:String(req.query.category||''),status:String(req.query.status||''),seller:String(req.query.seller||''),minPrice:String(req.query.minPrice||''),maxPrice:String(req.query.maxPrice||''),minRating:String(req.query.minRating||''),sort:'name',page:1,pageSize:10000});const esc=v=>`"${String(v??'').replaceAll('"','""')}"`;const rows=[['id','name','brand','seller','price_pix','price_card','rating','rating_count','last_status','collected_at','url'],...result.items.map(p=>[p.id,p.name,p.brand,p.seller,p.price_pix,p.price_card,p.rating,p.rating_count,p.last_status,p.collected_at,p.url])];res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="volix-products.csv"');res.send('\ufeff'+rows.map(r=>r.map(esc).join(';')).join('\n'));});
app.get('/api/search',async(req,res)=>{
  try{
    const q=String(req.query.q||'').trim();
    if(q.length<2)return res.status(400).json({error:'Informe uma busca com pelo menos 2 caracteres.'});
    if (providerMode()==='fixture') {
      // Em modo demonstração, uma URL de produto é tratada como uma entrada
      // válida do catálogo local. Não fazemos nenhuma requisição à Shopee.
      if (/^https?:\/\/(?:www\.)?shopee\.com\.br\//i.test(q)) {
        const existing=listProducts({q,sort:'updated',page:1,pageSize:20}).items;
        const fixture=getFixture(q);
        const results=existing.length
          ? existing.map(p=>({title:p.name,url:p.url,local:true}))
          : fixture
            ? [{title:fixture.name,url:q,local:true,fixture:true}]
            : [];
        return res.json({
          results,
          source:'local-catalog',
          external_url:`https://shopee.com.br/search?keyword=${encodeURIComponent(q)}`,
          message: results.length ? 'Produto identificado no catálogo local.' : 'URL válida. Clique em Adicionar para incluir no monitoramento local.'
        });
      }
      const local=listProducts({q,sort:'random',page:1,pageSize:20}).items;
      return res.json({
        results:local.map(p=>({title:p.name,url:p.url,local:true})),
        source:'local-catalog',
        external_url:`https://shopee.com.br/search?keyword=${encodeURIComponent(q)}`,
        message:'Pesquisa realizada no catálogo local.'
      });
    }
    try {
      const results=await searchShopee(q);
      res.json({results,source:'shopee'});
    } catch(e) {
      if(e.message!=='ANTI_BOT_CHALLENGE') throw e;
      const local=listProducts({q,sort:'random',page:1,pageSize:20}).items;
      res.json({
        results:local.map(p=>({title:p.name,url:p.url,local:true})),
        source:'local-fallback',
        external_url:`https://shopee.com.br/search?keyword=${encodeURIComponent(q)}`,
        message:'A Shopee bloqueou a busca automática. Abaixo estão correspondências do catálogo local e um link para a pesquisa completa na Shopee.'
      });
    }
  }catch(e){res.status(502).json({error:'Falha na busca',detail:e.message});}
});

async function collect(url, productId=null) {
  const cached=cache.get(url); if(cached && Date.now()-cached.at<CACHE_TTL) return cached.data;
  const started=Date.now();
  const mode=providerMode();
  if (mode==='fixture') {
    const fixture=getFixture(url);
    if(!fixture) throw new Error('FIXTURE_NOT_FOUND');
    const data=fixtureToProduct(fixture,url); const id=upsertProduct({...data,data_source:'fixture'});
    replaceAttributes(id,data.attributes); addImages(id,data.images); replaceVariants(id,data.variants); addPrices(id,data.price_pix,data.price_card);
    const result={...getProduct(id),source:'fixture',fallback:true,message:'Produto processado no modo demonstração local; nenhuma coleta live foi necessária.'};
    cache.set(url,{at:Date.now(),data:result});
    addCollectionLog({product_id:id,status:'success',message:'Coleta concluída em modo fixture configurado.',duration_ms:Date.now()-started});
    return result;
  }
  if ((mode==='authorized' || mode==='auto') && authorizedProviderConfigured()) {
    try {
      const data=await collectFromAuthorizedProvider(url);
      const id=upsertProduct({...data,data_source:'authorized_api'});
      replaceAttributes(id,data.attributes); addImages(id,data.images); replaceVariants(id,data.variants); addPrices(id,data.price_pix,data.price_card);
      const result={...getProduct(id),source:'authorized_api',fallback:false};
      cache.set(url,{at:Date.now(),data:result});
      lastDiagnostics.set(url,{url,source:'authorized_api',status:'success',attempts:1,at:new Date().toISOString()});
      addCollectionLog({product_id:id,status:'success',message:'Coleta concluída pela fonte autorizada configurada.',duration_ms:Date.now()-started});
      return result;
    } catch (e) {
      console.warn(`[provider] fonte autorizada indisponível: ${e.message}; seguindo para o collector público.`);
      lastDiagnostics.set(url,{url,source:'authorized_api',status:'error',reason:e.message,status_code:e.status??null,at:new Date().toISOString()});
    }
  }
  if (mode==='authorized') throw new Error('AUTHORIZED_PROVIDER_UNAVAILABLE');
  if (!publicCollectionAvailable()) {
    const status=providerStatus({authorized:authorizedProviderConfigured()});
    const fixture=FIXTURE_FALLBACK?getFixture(url):null;
    if(fixture){
      const data=fixtureToProduct(fixture,url); const id=upsertProduct({...data,data_source:'fixture'});
      replaceAttributes(id,data.attributes); addImages(id,data.images); replaceVariants(id,data.variants); addPrices(id,data.price_pix,data.price_card);
      const result={...getProduct(id),source:'fixture',fallback:true,live_blocked:true,message:'Coleta pública em cooldown após bloqueio; usando snapshot de demonstração sem gerar novas requisições.'};
      cache.set(url,{at:Date.now(),data:result});
      addCollectionLog({product_id:id,status:'success',message:'Fallback durante cooldown do collector público.',duration_ms:Date.now()-started});
      return result;
    }
    // Mesmo sem fixture, o fluxo de monitoramento não deve virar erro 502 só porque
    // o collector público está em cooldown. Salvamos a URL como pendente e evitamos
    // novas requisições à Shopee até o cooldown terminar.
    const match=String(url).match(/-i\.(\d+)\.(\d+)/i);
    const id=productId || createPendingProduct({url,shopee_shop_id:match?.[1]??null,shopee_item_id:match?.[2]??null});
    addCollectionLog({product_id:id,status:'blocked',message:'Coleta pública em cooldown após bloqueio anti-bot. Produto mantido como pendente sem gerar novas requisições.',duration_ms:Date.now()-started});
    const result={...getProduct(id),source:'pending',blocked:true,fallback:false,live_blocked:true,message:'A Shopee bloqueou a coleta automática. O produto continua monitorado e uma nova tentativa será feita após o cooldown.'};
    cache.set(url,{at:Date.now(),data:result});
    return result;
  }
  try {
    const data=await scrapeShopee(url);
    const id=upsertProduct({...data,data_source:'public_http'}); replaceAttributes(id,data.attributes); addImages(id,data.images); replaceVariants(id,data.variants); addPrices(id,data.price_pix,data.price_card);
    clearPublicBlock(); const result={...getProduct(id),source:'public_http'}; cache.set(url,{at:Date.now(),data:result});
    lastDiagnostics.set(url,{url,source:'public_http',status:'success',attempts:1,at:new Date().toISOString()});
    addCollectionLog({product_id:id,status:'success',message:'Coleta pública concluída com sucesso',duration_ms:Date.now()-started});
    return result;
  } catch (e) {
    const blocked=e.message==='ANTI_BOT_CHALLENGE' || [401,403,429].includes(e.status);
    const diagnostic={url,source:'public_http',status:blocked?'blocked':'error',reason:e.message,status_code:e.status??e.diagnostics?.last_status??null,attempts:e.diagnostics?.attempts??null,final_url:e.diagnostics?.final_url??null,content_type:e.diagnostics?.content_type??null,duration_ms:Date.now()-started,at:new Date().toISOString()};
    lastDiagnostics.set(url,diagnostic);
    if(blocked) markPublicBlocked('shopee.com.br', e.message, e.retryAfterMs||0);
    addCollectionLog({product_id:productId,status:blocked?'blocked':'error',message:blocked?`Shopee recusou a coleta automatizada (${e.status??e.diagnostics?.last_status??'challenge'}). Tentando snapshot local autorizado para demonstração.`:e.message,duration_ms:Date.now()-started});
    if(blocked && FIXTURE_FALLBACK){
      const fixture=getFixture(url);
      if(fixture){
        const data=fixtureToProduct(fixture,url);
        const id=upsertProduct({...data,data_source:'fixture'});
        replaceAttributes(id,data.attributes); addImages(id,data.images); replaceVariants(id,data.variants); addPrices(id,data.price_pix,data.price_card);
        const result={...getProduct(id),source:'fixture',fallback:true,live_blocked:true,message:'A Shopee bloqueou a coleta pública; o sistema ativou o snapshot de demonstração para manter o fluxo operacional.'};
        cache.set(url,{at:Date.now(),data:result});
        lastDiagnostics.set(url,{...diagnostic,source:'fixture',fallback:true});
        addCollectionLog({product_id:id,status:'success',message:'Fallback para fixture de demonstração após bloqueio anti-bot; nenhum dado live foi inventado.',duration_ms:Date.now()-started});
        return result;
      }
    }
    // Bloqueio sem fixture: não propagar como erro de aplicação. O item continua
    // monitorado como pendente e o scheduler poderá tentar novamente mais tarde.
    const match=String(url).match(/-i\.(\d+)\.(\d+)/i);
    const id=productId || createPendingProduct({url,shopee_shop_id:match?.[1]??null,shopee_item_id:match?.[2]??null});
    const result={...getProduct(id),source:'pending',blocked:true,fallback:false,live_blocked:true,message:'A Shopee bloqueou a coleta pública. O produto foi salvo como pendente; nenhuma técnica de bypass foi usada.'};
    cache.set(url,{at:Date.now(),data:result});
    return result;
  }
}
async function queuedCollect(url,id=null){return enqueue(()=>collect(url,id));}
app.post('/api/products',async(req,res)=>{
  try{
    const url=String(req.body?.url||'').trim();
    if(!isShopeeUrl(url))return res.status(400).json({error:'Informe uma URL canônica de produto da Shopee Brasil.'});
    res.status(201).json(await queuedCollect(url));
  }catch(e){
    if(e.message==='ANTI_BOT_CHALLENGE'){
      const match=String(req.body?.url||'').match(/-i\.(\d+)\.(\d+)/i);
      const id=createPendingProduct({url:String(req.body?.url||'').trim(),shopee_shop_id:match?.[1]??null,shopee_item_id:match?.[2]??null});
      addCollectionLog({product_id:id,status:'blocked',message:'A Shopee respondeu com um desafio anti-bot. Produto salvo como pendente para nova tentativa.',duration_ms:null});
      const p=getProduct(id); const fixture=FIXTURE_FALLBACK?getFixture(String(req.body?.url||'').trim()):null;
      if(fixture){
        const data=fixtureToProduct(fixture,String(req.body?.url||'').trim());
        const fid=upsertProduct({...data,data_source:'fixture'}); replaceAttributes(fid,data.attributes); replaceVariants(fid,data.variants); addImages(fid,data.images); addPrices(fid,data.price_pix,data.price_card);
        addCollectionLog({product_id:fid,status:'success',message:'Fallback para fixture de demonstração após bloqueio anti-bot; nenhum dado live foi inventado.',duration_ms:null});
        return res.status(201).json({...getProduct(fid),blocked:true,fallback:true,source:'fixture',message:'A Shopee bloqueou a coleta pública; o produto foi salvo usando um snapshot de demonstração. O link live continua disponível.'});
      }
      return res.status(201).json({...p,blocked:true,source:'pending',message:'Produto salvo, mas a coleta foi bloqueada pelo anti-bot da Shopee.'});
    }
    res.status(502).json({error:'Falha na coleta',detail:e.message});
  }
});
app.post('/api/products/:id/collect',async(req,res)=>{
  try{
    if(!validId(req.params.id))return res.status(400).json({error:'ID inválido'});
    const p=getProduct(Number(req.params.id));
    if(!p)return res.status(404).json({error:'Produto não encontrado'});
    res.json(await queuedCollect(p.url,p.id));
  }catch(e){
    if(e.message==='ANTI_BOT_CHALLENGE'){
      const product=getProduct(Number(req.params.id));
      const fixture=FIXTURE_FALLBACK?getFixture(product.url):null;
      if(fixture){
        const data=fixtureToProduct(fixture,product.url); const fid=upsertProduct({...data,data_source:'fixture'}); replaceAttributes(fid,data.attributes); replaceVariants(fid,data.variants); addImages(fid,data.images); addPrices(fid,data.price_pix,data.price_card);
        addCollectionLog({product_id:fid,status:'success',message:'Fallback para fixture de demonstração após bloqueio anti-bot; nenhum dado live foi inventado.',duration_ms:null});
        return res.status(200).json({...getProduct(fid),blocked:true,fallback:true,source:'fixture',message:'A Shopee bloqueou a coleta pública; exibindo snapshot de demonstração para manter o monitoramento funcional.'});
      }
      return res.status(200).json({...product,blocked:true,source:'pending',message:'Nova tentativa bloqueada pelo anti-bot da Shopee. O produto continua monitorado.'});
    }
    res.status(502).json({error:'Falha na coleta',detail:e.message});
  }
});

const interval=process.env.COLLECTION_CRON||'0 */6 * * *';
const job=cron.schedule(interval,async()=>{for(const p of listProducts({page:1,pageSize:10000}).items){try{await queuedCollect(p.url,p.id);console.log(`[scheduler] coleta concluída id=${p.id}`);}catch(e){console.warn(`[scheduler] falha id=${p.id} erro=${e.message}`);}}});
const port=Number(process.env.PORT||3000);
const server=app.listen(port,()=>console.log(`Volix rodando em http://localhost:${port}`));
const shutdown=()=>{job.stop();server.close(()=>process.exit(0));};
process.on('SIGINT',shutdown); process.on('SIGTERM',shutdown);
export { app, enqueue, processQueue };
