# Documentação técnica — Volix

## 1. Objetivo
Aplicação local de monitoramento de produtos públicos da Shopee Brasil, com coleta, persistência, enriquecimento e histórico de preços.

## 2. Arquitetura
`Frontend estático → Express API → Scraper/Parser → Repository → SQLite`.

O scheduler chama o mesmo serviço de coleta em intervalos configuráveis.

## 3. Fluxo de cadastro
1. Operador cola uma URL canônica ou pesquisa um termo.
2. API valida a origem/formato da URL.
3. Scraper faz requisição com timeout.
4. Em falha transitória, aplica retry e backoff exponencial.
5. Parser extrai nome, descrição, IDs, preços, atributos, imagens e variações disponíveis.
6. Repository atualiza o produto.
7. Uma nova coleta de preço é inserida em `price_history` sem apagar registros anteriores.
8. Dashboard mostra último preço e histórico.

## 4. Persistência
O SQLite usa foreign keys, índices e tabelas normalizadas. O histórico é append-only no fluxo normal da aplicação.

## 5. Resiliência
- Timeout configurável.
- Quatro tentativas por padrão.
- Backoff exponencial.
- Logs de tentativa, sucesso e falha.
- Detecção de HTTP 401/403/429 e sinais comuns de desafio.
- Falha de um produto no scheduler não interrompe os demais.

## 6. Anti-bot / Akamai
A aplicação não implementa evasão de controles de acesso. Em vez disso, identifica desafios/bloqueios e retorna um erro explícito. A estratégia é compatível com o requisito do teste de documentar a abordagem e limitações. Para produção, deve-se usar uma fonte autorizada quando disponível.

## 7. Modelo de dados
`product`: identidade e estado atual.

`product_attribute`: pares chave/valor da ficha técnica.

`price_history`: `price_pix`, `price_card`, moeda e timestamp.

`product_image`: URLs e posição.

`product_variant`: SKU/nome/preços quando disponíveis.

## 8. Interface
A interface permite:
- adicionar por URL;
- pesquisar;
- adicionar resultado da pesquisa;
- recoletar;
- visualizar detalhes;
- abrir a página original;
- visualizar atributos, imagens, variações e histórico.

## 9. Observabilidade
O sistema registra cada tentativa finalizada em `collection_log`, diferenciando `success`, `blocked` e `error`, além de duração e timestamp. O dashboard mostra indicadores das últimas 24 horas e os últimos logs.

## 10. Testes
Existem testes para:
- parser de metadados e preço;
- detecção de bloqueio;
- extração de IDs/preços do payload;
- persistência e histórico no SQLite.

## 11. Dados iniciais
`backend/data/volix.sqlite` contém 1000 produtos monitorados e um snapshot inicial de preço para tornar a aplicação demonstrável. Uma nova coleta deve ser executada antes da entrega para atualizar os dados. O seed de demonstração reinicializa o banco local e recria exatamente 1000 produtos funcionais, todos como `fixture`, para que a apresentação não dependa de bloqueios do marketplace.

## 12. Entrega
Antes de enviar:
1. instalar dependências;
2. executar `npm test`;
3. executar `npm run seed`;
4. executar `npm start`;
5. abrir o dashboard;
6. testar cadastro, busca, coleta, detalhes e histórico;
7. confirmar novamente os links de referência da Shopee.

## 13. Melhorias futuras
Worker/fila distribuída, métricas, cache, testes de integração HTTP, gráficos de histórico, preços por SKU mais completos, imagem Docker própria e integração autorizada para coleta.

## Recursos de operação adicionados na versão final

### Filtros, ordenação e paginação
A listagem permite pesquisar por nome/marca/vendedor, filtrar por categoria e pelo último status de coleta, ordenar por preço ou nome e paginar os resultados. Isso prepara a interface para uma lista maior sem alterar o modelo do MVP.

### Comparação
A interface permite selecionar produtos monitorados e comparar preço PIX, preço no cartão, avaliação e vendedor. A comparação usa somente dados já persistidos no SQLite.

### Exportação
`GET /api/export.csv` exporta a visão filtrada dos produtos em CSV UTF-8 com BOM, facilitando análise externa sem criar uma funcionalidade fora do escopo.

### Fila e cache
As coletas são colocadas em uma fila em memória e executadas de forma serial. Um cache curto por URL evita duplicações imediatas. A intenção é demonstrar throttling operacional e reduzir carga sobre a fonte pública, não contornar controles anti-bot.

### Health check
`GET /api/health` valida o SQLite e informa fila, execução e uptime.

### Limite deliberado de escopo
Não foram adicionados autenticação, pagamentos, carrinho, vendas ou outros módulos de e-commerce porque não contribuem diretamente para o objetivo do teste: monitorar dados públicos de produtos, enriquecer o banco e operar coletas.


## Estratégia de fontes

A aplicação tenta primeiro a coleta pública HTTP. Se a Shopee responder com bloqueio e houver snapshot correspondente, usa fixture de demonstração, marcando `data_source=fixture` e deixando explícito na interface que não é dado live. Para produção, `backend/src/providers.js` é o ponto de extensão de uma integração oficialmente autorizada.

## Fonte autorizada / Shopee API

O projeto possui um adapter opcional para uma fonte autorizada. Ele é ativado por `SHOPEE_AUTHORIZED_PROVIDER_URL` e, opcionalmente, `SHOPEE_AUTHORIZED_PROVIDER_TOKEN`.

O adapter não presume um endpoint público, assinatura ou contrato da Shopee: a integração deve ser fornecida pela própria Shopee ou por um serviço que tenha autorização para disponibilizar esses dados. Quando configurada, a fonte autorizada tem prioridade; se estiver indisponível, o sistema segue para o collector HTTP público e, se houver bloqueio, para o fixture de demonstração.

Isso mantém a aplicação preparada para dados live sem tentar contornar CAPTCHA, Akamai ou outras medidas de segurança. Os Termos da Shopee Brasil restringem robôs/spiders e processos automáticos para monitorar/copiar conteúdo sem consentimento prévio por escrito e também proíbem tentar superar medidas de segurança.

## V6 — Provider chain, circuit breaker e operação cloud-ready

A V6 separa explicitamente a fonte de dados da lógica de normalização/persistência.

### Cadeia de providers

1. `authorized`: integração autorizada configurada pelo ambiente.
2. `public_http`: coletor público, usado apenas quando permitido/configurado.
3. `fixture`: snapshot local identificado como demonstração.

A V6 **não tenta derrotar CAPTCHA, Akamai, fingerprinting, rate limits ou outras medidas de segurança**. Quando a fonte pública recusa a automação, o evento é registrado e um circuit breaker entra em cooldown para evitar novas requisições desnecessárias.

### Circuit breaker

Após `401/403/429` ou challenge anti-bot, o collector público entra em cooldown (`PUBLIC_COLLECTION_COOLDOWN_MS`, padrão 15 min). Durante o cooldown, o sistema não insiste em novas requisições públicas e usa o fixture quando disponível.

Isso reduz pressão sobre a origem, evita loops de retry e deixa o comportamento observável.

### Evolução cloud

- API HTTP → Cloud Run Service
- Coleta agendada → Cloud Scheduler + Cloud Run Job
- Fila local → Pub/Sub
- SQLite local → Cloud SQL
- Segredos → Secret Manager
- Logs/métricas → Cloud Logging + Cloud Monitoring

O código local mantém essas fronteiras explícitas para permitir migração sem reescrever a regra de negócio.
